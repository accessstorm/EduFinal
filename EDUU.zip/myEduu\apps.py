from django.apps import AppConfig


class MyeduuConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myEduu'
